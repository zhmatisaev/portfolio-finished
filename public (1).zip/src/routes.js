export const routes = {
  home: "/",
  login: "/login",
  sign_up: "/sign-up",
  user_profile: "/profile",
  user_delete: "/delete",
};
